const v = list(10, 20, 30);
const m1 = list(list(1, 2, 3), list(3, 5, 1), list(1, 1, 1));
const m2 = list(list(1, 2, 3), list(4, 5, 6), list(7, 8, 9));

matrix_times_vector(m1, v);
// transpose(m1);
// matrix_times_matrix(m1, m2);
