process_query('assert(supervisor(list("Julius", "Caesar"), list("Julius", "Caesar")))');
first_answer('supervisor($x, $x)');
