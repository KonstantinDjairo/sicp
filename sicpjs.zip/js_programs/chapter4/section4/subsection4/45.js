: is_list_construction(exp)
? unparse(make_application(make_name("list"), 
                           element_expressions(exp)))
